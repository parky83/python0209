# ex03_03_복리계산

init_money=24
interest=0.06
years=382

init_money*(1+interest)**years
111442737812.28842
