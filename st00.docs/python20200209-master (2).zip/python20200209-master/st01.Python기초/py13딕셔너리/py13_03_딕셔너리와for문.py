# 딕셔너리를 선언합니다.


# 딕셔너리 열거

# key 만 열거

# value 만 열거

# key, value를 쌍으로 열거
