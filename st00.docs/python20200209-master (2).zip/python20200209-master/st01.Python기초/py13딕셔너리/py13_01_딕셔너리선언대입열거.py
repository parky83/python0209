# 딕셔너리의 CRUD3S
# C: create.
# R: read
# U: update
# D: delete
# S: search
# S: sort
# S: shuffle

# 딕셔너리 선언하기

# 요소 추가 전에 내용을 출력해봅니다.

# 딕셔너리 추가

# 선택 연사자로 딕셔너리 읽기

# 존재하지 않는 키: 선택 연산자로 없는 키에 접근하면 에러 발생.
# dictionary["존재하지 않는 키"] # KeyError


# 딕셔너리 수정


# 딕셔너리 삭제.


# 딕셔너리 키 존재 여부 확인
# value = dictionary["존재하지 않는 키"]  # KeyError

# 키가 존재하지 않는 경우의 확인 방법 :  None 사용

# 출력합니다.


# 딕셔너리 열거

# key 만 열거

# value 만 열거

# key, value를 쌍으로 열거
