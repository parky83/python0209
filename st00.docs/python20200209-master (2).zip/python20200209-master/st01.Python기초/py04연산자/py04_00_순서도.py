width1 = 10
width2 = 10
height1 = 5
height2 = 7

area1 = width1 * height1
area2 = width2 * height2
totArea = area1 + area2

print("area1 =", area1)
print("area2 =", area2)
print("totArea =", totArea)
