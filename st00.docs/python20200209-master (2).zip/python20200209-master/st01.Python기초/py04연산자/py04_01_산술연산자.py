# py04_01_산술연산자

t = 7 / 4
print( t ) # 1.75

t = 7 // 4
print( t ) # 1

t = 7%4
print( t ) # 3