# py04_11_비교연산자.py

print("hello" == "hello")  # True
print("hello" == "Hello")  # False
print(12 == 12.0)  # True
print(12 == "12")  # False


print(True)
print(False)

flag = True
print(flag)

flag = (2 > 3)
print(flag)

print(10 == 100)
print(10 != 100)
print(10 < 100)
print(10 > 100)
print(10 <= 100)
print(10 >= 100)


print("가방" == "가방")
print("가방" != "하마")
print("가방" < "하마")
print("가방" > "하마")


x = 25
print( 10 < x < 30 ) # True
print( 10 < x and x < 30 ) # True
print( 40 < x < 60)  # False
print( 40 < x and x < 60 ) # True

