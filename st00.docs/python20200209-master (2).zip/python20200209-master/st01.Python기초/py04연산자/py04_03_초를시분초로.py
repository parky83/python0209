# 예제로 초 단위의 시간을 받아서 몇 분 몇 초인지를 계산하여 보자.
sec = 1000
min = 1000 // 60
remainder = 1000 % 60
print(min, remainder)
