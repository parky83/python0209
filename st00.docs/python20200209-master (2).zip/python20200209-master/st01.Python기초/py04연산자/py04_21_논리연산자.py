# 불린 타입
print(not True)
print(not False)

# and 연산자
print(True and True)
print(True and False)
print(False and True)
print(False and False)
print()

# or 연산자
print(True or True)
print(True or False)
print(False or True)
print(False or False)
