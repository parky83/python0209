
# 재정의 연산자
# __str__
# __add__              +
# __sub__              -
# __mul__              *
# __floordiv__         //
# __mod__              %
# __divmod__           divmod()
# __pow__              pow() , **
# __lshift__           <<
# __rshift__           >>
# __and__              &
# __xor__              ^




# 재정의 메서드 
# __str__(self):
# __eq__(self, value)
# __ne__(self, value)
# __gt__(self, value)
# __ge__(self, value)
# __lt__(self, value)


