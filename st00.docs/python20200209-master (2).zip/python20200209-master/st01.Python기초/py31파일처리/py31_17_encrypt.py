key = "abcdefghijklmnopqrstuvwxyz"

# 평문을 받아서 암호화하고 암호문을 반환한다.


# 암호문을 받아서 복호화하고 평문을 반환한다.


