
# Traceback (most recent call last):
#   File ".\2-33.py", line 4, in <module>
#     string + number
# TypeError: must be str, not int

string = "���ڿ�"
number = 273

string + number
