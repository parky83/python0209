
# IndexError 예외
# Traceback (most recent call last):
#   File ".\py08_IndexError.py", line 3, in <module>
#     print("안녕하세요"[10])
# IndexError: string index out of range

array = [1, 2, 3]
print(array[3])  # IndexError


# 출력합니다.
print("# IndexError 예외")
print("안녕하세요"[10])
