from math import *

time1 = 10/20
height = sqrt(3**2+4**2)
time2 = height/10
time3 = height/30
time4 = 8/20
total = time1+time2+time3+time4

print(total)
