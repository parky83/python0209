def add(x,  y):  # x, y 는 매개변수라고 칭한다.
    result = x + y
    return result


a = 3
b = 4
value = add(a, b)  # a,b 는 인자라고 칭한다
print(value)
