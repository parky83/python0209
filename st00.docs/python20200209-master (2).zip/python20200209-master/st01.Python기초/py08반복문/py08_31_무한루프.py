
while True  :
    # 반복되는 코드를 적는다.
    print(".", end="")
