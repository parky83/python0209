# 왜 반복이 사용하나?


# 순차문
print("환영합니다")
print("환영합니다")
print("환영합니다")
print("환영합니다")
print("환영합니다")

# for문
for x in range(0, 5, 1):
    print("for", "환영합니다")

# while문
i = 0
while i < 5:
    print("while", "환영합니다")
    i = i + 1 # i를 1씩 증가 시킨다.

# 
print('반복이 종료되었습니다.')