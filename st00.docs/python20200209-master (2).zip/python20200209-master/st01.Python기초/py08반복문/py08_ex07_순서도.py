
A = 1

while A < 5:
    A = A + 1
print(A)
