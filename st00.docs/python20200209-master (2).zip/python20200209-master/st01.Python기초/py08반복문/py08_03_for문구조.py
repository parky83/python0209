
# [] : 리스트. 리스트는 배열과 같다.
# for문
for name in ["철수", "영희", "길동", "유신"]:
    print("안녕! " , name)


# for문
for x in [1, "a", True, None, ["가"]]:
    print(x, end=",")
print()


# for문
for x in "abcd faoa":
    print(x, end=",")
print()
