
gu = int(input("Number:"))

print("Resutl:")
for x in range(9, 0, -1):
    print(gu, "*", x, "=", gu*x)
