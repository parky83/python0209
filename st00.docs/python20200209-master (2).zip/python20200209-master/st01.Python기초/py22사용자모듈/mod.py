"""

py22사용자모듈 폴더 선택 후 오른쪽 마우스 클릭 >> 컨텍스트 메뉴에서 Open in Terminal 메뉴 선택

Windows PowerShell
Copyright (C) Microsoft Corporation. All rights reserved.
새로운 크로스 플랫폼 PowerShell 사용 https://aka.ms/pscore6
C:....\py22사용자모듈>   python  입력 후 엔터

>>> # import 모듈이름
>>> import mod1
>>> print( mod1.add(3,4) )
7
>>> # from 모듈이름 import 모듈함수
>>> from mod1 import sum
>>> print( sum(3,4) )
7
>>> exit()

"""
