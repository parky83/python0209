# py01_01_Hello

# 주서
# 문자열은 큰따옴표로 감싼다.

# Hello, Python  을 모니터 출력(표준출력)하시오.
print("Hello, Python!!!")
print("sejoong")

print(". it"s me")
print(". i like \n you.")
print("\n")
print("")

print("내 이름 {0} 나이 {1}".format("sejoong", 132))

print("결과값은", 2*7, "입니다.")  # 결과값은 14 입니다.
