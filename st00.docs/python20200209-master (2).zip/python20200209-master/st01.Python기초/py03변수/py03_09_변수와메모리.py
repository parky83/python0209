
# 파이썬에서 변수는 어떤 데이터든지 저장할 수 있다.
# 파이썬에서는 모든 것이 객체로 처리된다.

a = 3
print("reference address >> ", id(a))


a = 1000
print("reference address >> ", id(a))


a = 1000.01
print("reference address >> ", id(a))
