score = 20
score = 30
print(score)  # 30


width = 10
height = 20
area = width * height
print(area)  # 200
