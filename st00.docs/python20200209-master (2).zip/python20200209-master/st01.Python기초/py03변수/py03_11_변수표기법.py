# 표기법 종류
# 카멜 표기법
#     camelCase, backgroundColor, typeName, iPhone
# 파스칼 표기법
#     CamelCase, BackgroundColor, TypeName, IPhone
# 헝가리언 표기법
#     strCamelCase, nBackgroundColor, strTypeName, IPhone