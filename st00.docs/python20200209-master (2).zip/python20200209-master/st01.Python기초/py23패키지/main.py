
# 패키지의 모듈을 사용해보겠습니다. 다음 내용을 프로젝트 폴더(C:\project) 안에 main.py 파일로 저장한 뒤 실행해보세요(main.py 파일을 game.graphic 패키지 폴더 안에 넣으면 안 됩니다).
#
# import 패키지.모듈
# 패키지.모듈.변수
# 패키지.모듈.함수()
# 패키지.모듈.클래스()
# main.py


# game.graphic 패키지의 geometry 모듈을 가져옴
# game.sound 패키지의 echo 모듈을 가져옴
# game.operation 패키지의 run 모듈을 가져옴

# geometry 모듈의 triangle_area 함수 사용

# geometry 모듈의 rectangle_area 함수 사용

