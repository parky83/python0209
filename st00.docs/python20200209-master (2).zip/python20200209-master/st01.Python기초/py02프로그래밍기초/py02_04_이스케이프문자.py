# py02_04_이스케이프문자.py

size = "sin\'gl\"e \\  \nquote string  \u0041"
print(size)
