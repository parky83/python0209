# py02_01_keyword.py

import keyword # 예약어 모듈(모듈 가져올때 사용)

print( keyword.kwlist )