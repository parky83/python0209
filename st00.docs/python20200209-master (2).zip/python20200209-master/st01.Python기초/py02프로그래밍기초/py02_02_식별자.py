# py02_02_식별자.py

speed
earthPopulation
_count
$value
반복횟수 = 0
henry8

1stPrizeMoney
break
