

# "grade 가 60보다 크다면 합격입니다"
grade = 75

if grade > 60:
    print("합격입니다")

print("종료")


# grade 값을 표준 입력을 받습니다.

grade = input("점수를 입력하시오 >>")
grade = int( grade ) 

if grade>65:
    print("합격입니다")

print("종료")



# # 출력 예시1
# 합격입니다
# 종료



# 출력 예시2
# 종료

