
x = input("정수를 입력하세요")
y = input("정수를 입력하세요")

x = int(x)
y = int(y)


if x> y:
    print(x, y) 
else:
    print(y, x) 

if x> y:
    print(x, y) 
elif x == y:
    print(x, y)
else:
    print(y, x) 